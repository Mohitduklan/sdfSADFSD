
FIELDS = {
    "CLOSE": "TR.PriceClose"
}
INDEX = {
    "BSE200": ".BSE200",
    "BSE100": ".BSE100",
    "BSE500": ".BSE500",
    "BSE400MS": ".SPB40YUT"
}
FREQUENCIES = {
    "Q": "Quarterly",
    "M": "Monthly",
    "W": "Weekly",
    "Y": "Yearly",
    "D": "Daily"
}
FREQUENCY_CODE = {
    "Q": "Q", 
    "M": "M", 
    "W": "W-FRI", 
    "Y": "YS"
}
TRADING_DAYS_IN_A_YEAR = 252
TRADING_DAYS_IN_A_MONTH = 21
