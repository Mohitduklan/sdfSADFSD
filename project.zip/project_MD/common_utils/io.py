import os
import yaml
import json

def parse_yaml(path):
    '''Parse yaml file'''
    assert os.path.exists(path), "Path do not exist for config."
    with open(path, 'r') as file:
        config = yaml.safe_load(file)
    return config

def parse_json(path):
    assert os.path.exists(path), "Path do not exist for config."
    with open(path, 'r') as file:
        config = json.load(file)
    return config
