import eikon as ek
import configparser as cp


def init_eikon(token_path):
    """Initializing eikon using token
    param:
        token_path: Config file path
    """
    cfg = cp.ConfigParser()
    cfg.read(token_path)
    ek.set_app_key(cfg["eikon"]["app_id"])

def get_data_from_eikon(stock_list, fields, parameters, tries=3):
    '''Get_data from Eikon
    param:
        stock_list: List of isins
        fields: fields to extract
        parameters: parameters
    '''
    tried = 0
    while tried<tries:
        try:
            data, _ = ek.get_data(stock_list, fields=fields, parameters=parameters)
            return data
        except ek.EikonError as exe:
            tried += 1
            print(f"Try {tried}/{tries}. An error occurred: {exe}")
    raise ek.EikonError(message="Custom error message: Unable to get data from eikon.", code=400)
