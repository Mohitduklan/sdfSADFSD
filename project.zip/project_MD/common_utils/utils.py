from datetime import datetime

def validate_date_format(date):
    """Validating dates
    param:
        date_name: date string
    """
    try:
        datetime.strptime(date, "%Y-%m-%d")
    except ValueError as exc:
        raise ValueError(f'"{date}" has incorrect format.') from exc