'''Main module to run all data download functions'''

from common_utils import io, utils, eikon_utils
from data_download import isin_price_download
from data_download import index_price_download
from data_download import fundamental_data_download

def main():
    '''Main function to run all data download functions'''
    isin_price_config_path = "./configs/isin_price_data_download_config.json"
    index_price_config_path = "./configs/index_price_data_download_config.json"
    fundamental_config_path = "./configs/fundamental_data_download_config.json"
    
    isin_price_config = io.parse_json(isin_price_config_path)
    index_price_config = io.parse_json(index_price_config_path)
    fundamental_config = io.parse_json(fundamental_config_path)
    
    # Initialize eikon
    eikon_utils.init_eikon(isin_price_config["eikon_config"])

    # Downloading isin price data
    isin_price_download.download(isin_price_config)
    # Downloading index price data
    index_price_download.download(index_price_config)
    # Downloading fundamental data
    fundamental_data_download.download(fundamental_config)

if __name__ == "__main__":
    main()
