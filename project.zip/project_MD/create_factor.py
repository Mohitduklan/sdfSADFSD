import os
import numpy as np
import pandas as pd
from factor_creation.fundamental_ratio import financial_factors_ratios
from factor_creation.factor_methods import (
    calc_down_side_deviation,
    calc_up_side_deviation,
    calc_kelly_non_annualized,
    calc_sharpe,
    calc_sortino_ratio,
    calc_vol_factor,
)
from factor_creation.momentum_factors import (
    momentum_factors,
    cross_sectional_momentum_with_BSE200,
    lagged_price_momentum,
    weighted_lagged_price_momentum,
    price_momentum_ratios_monthly,
)
from factor_creation.regression_factors import regression_based_factors
from common_utils import io

def read_ohlc_files(folder_name, file_list):
    """
    directory_path: Path of folder from which OHLC files are saved
    """
    frames = []
    for file_name in file_list:
        file_path = os.path.join(folder_name, file_name)
        data_frame = pd.read_csv(file_path, index_col="Date", parse_dates=True)
        frames.append(data_frame)
    return frames


def save_daily_price_factors(config, data):
    daily_price_factor_list = {
        "Data_DownsideDev": calc_down_side_deviation,
        "Data_UpsideDev": calc_up_side_deviation,
        "Data_Kelly_non_annualized": calc_kelly_non_annualized,
        "Sharpe": calc_sharpe,
        "Sortino": calc_sortino_ratio,
        "Volatility": calc_vol_factor,
    }
    data = data.replace("nan", np.nan).fillna(method="ffill")
    data = data.sort_index()
    daily_return = np.log(data) - np.log(data.shift(1))
    for frequency in config["frequencies"]:
        for function_name, function_callable in daily_price_factor_list.items():
            if function_name == "Volatility":
                for vol_period in config["volume_period"]:
                    vol_factor = calc_vol_factor(
                        daily_return,
                        vol_period=vol_period,
                        nperiods=config["daily_period"],
                        freq=frequency,
                    )
                    vol_factor.to_csv(
                        os.path.join(
                            config[r"factor_save_path"],
                            f"{function_name}_{vol_period}_{frequency}.csv",
                        )
                    )
            else:
                factor = function_callable(daily_return, nperiods=config["daily_period"], freq=frequency)
                factor.to_csv(os.path.join(config[r"factor_save_path"], f"{function_name}_{frequency}.csv"))


def momentum_based_factors(config, isin_monthly, index_monthly):
    momentum_factors(config, isin_monthly)
    cross_sectional_momentum_with_BSE200(config, isin_monthly, index_monthly)
    lagged_price_momentum(config, isin_monthly)
    weighted_lagged_price_momentum(config, isin_monthly)
    price_momentum_ratios_monthly(config, isin_monthly, index_monthly)


if __name__ == "__main__":
    config = io.parse_json("./configs/create_factors_config.json")
    # Creating output folder if not exist
    os.makedirs(config["factor_save_path"], exist_ok=True)

    # Reading isin for various frequency
    isin_daily, isin_weekly, isin_monthly = read_ohlc_files(config["ohlc_folder_path"], config["ohlc_isin_file_names"])

    # Reading index for various frequency
    index_daily, index_weekly, index_monthly = read_ohlc_files(config["ohlc_folder_path"], config["ohlc_index_file_names"])

    # daily return finantial factors
    save_daily_price_factors(config, isin_daily)

    # Financial factor ratios
    financial_factors_ratios(config)

    # Factor from momentum
    momentum_based_factors(config, isin_monthly, index_monthly)

    # Factors from regression
    regression_based_factors(config, isin_weekly, isin_monthly, index_weekly, index_monthly)
