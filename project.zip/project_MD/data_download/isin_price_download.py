import os
import tqdm
import pandas as pd
from common_utils import constants
from common_utils import eikon_utils
from common_utils import utils

def post_processing_merged_data(combine_data: pd.DataFrame, isin_list: list):
    '''Post processing the combined data
    param:
        combine_data: dataframe which is combined from isin csvs
        isin_list: list of isins
    return:
        field_name, modified_main_data
    '''
    field_name = combine_data.columns.values[-2]
    print("Field Name is : ", field_name)
    empty_data_frame = pd.DataFrame(columns=list(isin_list))
    empty_data_frame["Date"] = list(set(combine_data["Date"]))
    empty_data_frame = pd.melt(
        empty_data_frame,
        id_vars=["Date"],
        var_name="Instrument",
        value_name="Ignore",
    )
    empty_data_frame.drop(columns=["Ignore"], inplace=True)
    final_data_check = empty_data_frame.merge(
        combine_data[["Date", "Instrument", field_name]],
        how="left",
        on=["Date", "Instrument"],
    )

    modified_main_data = final_data_check.pivot_table(
        field_name, ["Date"], "Instrument", dropna=False, aggfunc="first"
    ).reset_index()
    return field_name, modified_main_data

def merge_data(isin_list: list, field: str, out_path: str):
    """Merging csv files of all the isin into one csv
    param:
        isin_list: list of isin
        out_path: path to save combined file
    """
    combine_data = pd.DataFrame()
    for isin in isin_list:
        try:
            data = pd.read_csv(os.path.join(out_path, f"{isin}_{field}.csv"))
            combine_data = pd.concat([combine_data, data])
        except FileNotFoundError as exe:
            print(f"Exception in combining data {isin}", exe)
            continue
    return combine_data

def get_data_for_isin(field: str, isin_list: list, out_path: str, frequency:str, config:dict):
    """Iterate over isin list which are not downloaded and download them
    param:
        field: field to download
        isin_list: list of isin
        outpath: path to save files
    """
    already_downloaded_files = os.listdir(out_path)
    # Eikon parameter for data extraction
    parameters = {
        "SDate": config["start_date"],
        "EDate": config["end_date"],
        "Frq": str(frequency),
    }
    fields = ["TR.RIC", constants.FIELDS[field], f"{constants.FIELDS[field]}.calcdate"]
    # Iterating over isin list
    for isin in tqdm.tqdm(isin_list):
        if f"{isin}_{field}.csv" not in already_downloaded_files:
            # Fetching data from eikon
            data = eikon_utils.get_data_from_eikon(
                stock_list=isin, fields=fields, parameters=parameters
            )

            data["RIC"] = isin
            ric_ticker = [x for x in list(set(data["RIC"])) if x]
            if ric_ticker[0]:
                data["RIC"] = ric_ticker[0]

            data.rename(columns={"Calc Date": "Date"}, inplace=True)
            # Saving data in csv
            data.to_csv(os.path.join(out_path, f"{isin}_{field}.csv"), index=False)


def get_price_data_refinative(isin_list, config, combine_path):
    """
    Iterate over fileds, isin and downloads the data for given time frequency
    param:
        time_frequency: string value defining time frequency eg: Q, M, D, Y
    """
    # Iterating over frequencies
    for time_frequency in config["frequencies"]:
        # Iterating over fields
        for field in config["fields"]:
            out_path = os.path.join(
                config["output_directory"],
                "OHLC_database",
                f"{field}_data",
                constants.FREQUENCIES[time_frequency],
            )

            os.makedirs(out_path, exist_ok=True)
            get_data_for_isin(field, isin_list, out_path, time_frequency, config)

            # combine data
            combine_data = merge_data(isin_list, field, out_path)
            # second last column of downloaded date from ek.get_data() is required field name
            field_name, modified_main_data = post_processing_merged_data(
                combine_data, isin_list
            )
            file_name = f"{field_name.replace(' ', '_')}_{constants.FREQUENCIES[time_frequency]}.csv"
            # TODO: Why saving in two places
            modified_main_data.to_csv(
                os.path.join(combine_path, file_name), index=False
            )

def download(config):
    # Date format check
    utils.validate_date_format(config["start_date"])
    utils.validate_date_format(config["end_date"])
    # Reading Schema file to get unique instuments
    isin_df = pd.read_excel(
        config["schema_file"], sheet_name="ISIN_mapping_500"
    )
    isin_list = isin_df["ISIN"].unique().tolist()
    combine_path = os.path.join(
        config["output_directory"], "OHLC_database", "combine_data"
    )
    os.makedirs(combine_path, exist_ok=True)

    get_price_data_refinative(isin_list, config, combine_path)
