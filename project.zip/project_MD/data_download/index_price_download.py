import os
from common_utils import constants
from common_utils import eikon_utils
from common_utils import utils


def get_index_price_data_refinative(index_list, time_frequency, config):
    """Downloading index data from eikon"""
    for index_name in index_list:
        index = constants.INDEX[index_name]
        fields = ["TR.PriceClose", "TR.PriceClose.calcdate"]
        parameters = {
            "SDate": config["start_date"],
            "EDate": config["end_date"],
            "Frq": time_frequency,
        }
        data = eikon_utils.get_data_from_eikon(index, fields=fields, parameters=parameters)
        data.rename(columns={"Price Close": "Close"}, inplace=True)
        data.rename(columns={"Calc Date": "Date"}, inplace=True)
        data.drop(["Instrument"], axis=1, inplace=True)

        combine_path = os.path.join(
            config["output_directory"], "OHLC_database", "combine_data"
        )
        file_name = f"{index_name}_{constants.FREQUENCIES[time_frequency]}.csv"

        data.to_csv(os.path.join(combine_path, file_name), index=False)

def download(config):
    # Date format check
    utils.validate_date_format(config["start_date"])
    utils.validate_date_format(config["end_date"])
    # Reading Schema file to get unique instuments
    index_list = config["index"]
    for time_frequency in config["frequencies"]:
        get_index_price_data_refinative(index_list, time_frequency, config)

