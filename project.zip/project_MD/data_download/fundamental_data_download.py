"""
Module downloads the fundamental data for ISIN
Parent
Date,INE228A01035,INE578A01017,INE794B01026
2023-03-31,18100500000.0,,2421223000.0
2023-06-30,20417100000.0,,5171655000.0
2023-09-30,20417100000.0,,5171655000.0
2023-12-31,20417100000.0,,5171655000.0

Primary
Date,INE228A01035,INE578A01017,INE794B01026
2023-03-31,26880700000.0,22969600000.0,3368522000.0
2023-06-30,32677600000.0,22381000000.0,5929645000.0
2023-09-30,32677600000.0,22381000000.0,5929645000.0
2023-12-31,32677600000.0,22381000000.0,5929645000.0

Consolidated
Date,INE228A01035,INE578A01017,INE794B01026
2023-03-31,26880700000.0,22969600000.0,3368522000.0
2023-06-30,32677600000.0,22381000000.0,5929645000.0
2023-09-30,32677600000.0,22381000000.0,5929645000.0
2023-12-31,32677600000.0,22381000000.0,5929645000.0

"""

import math
import os

import pandas as pd
import tqdm
from common_utils import constants
from common_utils import eikon_utils



def create_path(output_folder, consolidation_basis, fundamental_data_type, frequency):
    """Function is specific to this script.
    Create folders at specific path if not exists"""
    folders = ["raw_modified_files", "database_files", "logs"]
    for folder in folders:
        path = os.path.join(
            output_folder,
            folder,
            consolidation_basis,
            fundamental_data_type,
            constants.FREQUENCIES[frequency],
        )
        os.makedirs(path, exist_ok=True)


def request_in_batch(isin_list, fields, parameters):
    data = pd.DataFrame()
    # Iterating over ISIN list in batches
    # ISSUE: https://community.developers.refinitiv.com/questions/22857/backend-error-400-bad-request.html
    for i in range(0, len(isin_list), 50):
        ek_data = eikon_utils.get_data_from_eikon(
            stock_list=isin_list[i : i + 50],
            fields=fields,
            parameters=parameters
        )
        data = pd.concat([data, ek_data])
    return data


def post_processing_downloaded_data(
    config,
    data,
    isin_list,
    frequency,
    period,
    consolidation_basis,
    raw_modified_file_name,
    fundamental_data_formula,
    fundamental_data_type,
):
    fector_col_name, date_col_name = data.columns[1:3]
    # Drop NaN from Date Column
    data.dropna(subset=[date_col_name], inplace=True)
    data.rename(columns={date_col_name: "Date"}, inplace=True)

    output_data_index = pd.DataFrame(columns=isin_list)
    # Creating date dataframe
    date_range = pd.date_range(
        start=config["start_date"],
        end=config["end_date"],
        freq=constants.FREQUENCY_CODE[frequency],
    ).strftime("%Y-%m-%d")
    date_index = pd.DataFrame(date_range, columns=["Date"])

    output_data_index["Date"] = date_index["Date"]
    output_data_index = pd.melt(
        output_data_index, id_vars=["Date"], var_name="Instrument", value_name="Ignore"
    )

    final_data = output_data_index.merge(
        data, how="left", on=["Date", "Instrument"]
    )

    data["Frequency"] = frequency
    data["Period"] = period
    data["Data_Type"] = fundamental_data_type
    data["ConsolBasis"] = consolidation_basis


    modified_main_data = final_data.pivot_table(
        fector_col_name, ["Date"], "Instrument", dropna=False, aggfunc="first"
    ).reset_index()

    path = os.path.join(
        config["output_directory"],
        "raw_modified_files",
        consolidation_basis,
        fundamental_data_type,
        constants.FREQUENCIES[frequency],
        raw_modified_file_name,
    )
    modified_main_data.to_csv(path, index=False)

    path = os.path.join(
        config["output_directory"],
        "database_files",
        consolidation_basis,
        fundamental_data_type,
        constants.FREQUENCIES[frequency],
        f"{period}_{frequency}_{fundamental_data_formula.replace('TR.', '')}_TR_{consolidation_basis}.csv",
    )
    data.to_csv(path, index=False)


def download_fundamental_data(
    config,
    period,
    consolidation_basis,
    frequency,
    fundamental_data_type,
    isin_list,
    fundamental_data_formula_list,
):
    # error dict store ISIN if fundamentals not downloads
    error_dict = {}
    # Creating output paths
    create_path(config["output_directory"], consolidation_basis, fundamental_data_type, frequency)
    # Checking for already downloaded files
    already_downloaded_files = os.listdir(
        os.path.join(
            config["output_directory"],
            "raw_modified_files",
            consolidation_basis,
            fundamental_data_type,
            constants.FREQUENCIES[frequency],
        )
    )

    parameters = {
        "SDate": config["start_date"],
        "EDate": config["end_date"],
        "Frq": frequency,
        "period": period,
        "ConsolBasis": consolidation_basis,
        "ReportingState": "Orig",
    }
    # Iterating over fundamental formula
    for fundamental_data_formula in tqdm.tqdm(fundamental_data_formula_list):
        fields = [
            fundamental_data_formula,
            fundamental_data_formula + ".calcdate",
            "TR.RIC",
        ]
        raw_modified_file_name = f"{fundamental_data_formula.replace('TR.', '')}_TR_{period}_{frequency}_{consolidation_basis}.csv"
        if raw_modified_file_name not in already_downloaded_files:
            data = request_in_batch(isin_list, fields, parameters)
            if data.shape[0] > 0:
                post_processing_downloaded_data(
                    config,
                    data,
                    isin_list,
                    frequency,
                    period,
                    consolidation_basis,
                    raw_modified_file_name,
                    fundamental_data_formula,
                    fundamental_data_type,
                )
            error_dict[fundamental_data_formula] = set(isin_list) - set(
                data["Instrument"]
            )

    error_logs = pd.DataFrame(error_dict.items(), columns=["Field", "RIC"])
    error_logs.to_csv(
        os.path.join(
            config["output_directory"],
            "logs",
            consolidation_basis,
            fundamental_data_type,
            constants.FREQUENCIES[frequency],
            "error_logs.csv",
        )
    )


def merge_consolidated_parent_data(
    config, period, frequency, fundamental_data_type, isin_list, fundamental_data_formula
):
    date_index = pd.date_range(
        start=config["start_date"],
        end=config["end_date"],
        freq=constants.FREQUENCY_CODE[frequency],
    ).strftime("%Y-%m-%d")
    date_index = pd.DataFrame(date_index, columns=["Date"])

    # create output folder
    output_path = os.path.join(
        config["output_directory"],
        "raw_modified_files",
        "Merge",
        fundamental_data_type,
        constants.FREQUENCIES[frequency],
    )
    os.makedirs(output_path, exist_ok=True)

    for formula in tqdm.tqdm(fundamental_data_formula):
        try:
            consolidated_file_name = f"{formula.replace('TR.', '')}_TR_{period}_{frequency}_Consolidated.csv"
            consolidated_data_df = pd.read_csv(
                os.path.join(
                    config["output_directory"],
                    "raw_modified_files",
                    "Consolidated",
                    fundamental_data_type,
                    constants.FREQUENCIES[frequency],
                    consolidated_file_name
                )
            )

            parent_file_name = f"{formula.replace('TR.', '')}_TR_{period}_{frequency}_Parent.csv"
            parent_data_df = pd.read_csv(
                os.path.join(
                    config["output_directory"],
                    "raw_modified_files",
                    "Parent",
                    fundamental_data_type,
                    constants.FREQUENCIES[frequency],
                    parent_file_name,
                )
            )

            output_data = pd.DataFrame(columns=isin_list)
            output_data["Date"] = date_index["Date"]
            output_data.set_index("Date", inplace=True)

            for isin in isin_list:
                if (
                    isin
                    in consolidated_data_df.columns.tolist()
                    + parent_data_df.columns.tolist()
                ):
                    for date in output_data.index.tolist():
                        if math.isnan(
                            consolidated_data_df[isin]
                            .loc[consolidated_data_df["Date"] == date]
                            .values[0]
                        ):
                            if math.isnan(
                                parent_data_df[isin]
                                .loc[parent_data_df["Date"] == date]
                                .values[0]
                            ):
                                continue
                            else:
                                output_data.loc[date, isin] = parent_data_df[isin][
                                    parent_data_df["Date"] == date
                                ].values[0]
                        else:
                            output_data.loc[date, isin] = (
                                consolidated_data_df[isin]
                                .loc[consolidated_data_df["Date"] == date]
                                .values[0]
                            )

                if (
                    isin in parent_data_df.columns.tolist()
                    and isin not in consolidated_data_df.columns.tolist()
                ):
                    for date in output_data.index.tolist():
                        if math.isnan(
                            parent_data_df[isin]
                            .loc[parent_data_df["Date"] == date]
                            .values[0]
                        ):
                            continue
                        else:
                            output_data.loc[date, isin] = parent_data_df[isin][
                                parent_data_df["Date"] == date
                            ].values[0]

                if (
                    isin not in parent_data_df.columns.tolist()
                    and isin in consolidated_data_df.columns.tolist()
                ):
                    for date in output_data.index.tolist():
                        if math.isnan(
                            consolidated_data_df[isin]
                            .loc[consolidated_data_df["Date"] == date]
                            .values[0]
                        ):
                            continue
                        else:
                            output_data.loc[date, isin] = consolidated_data_df[isin][
                                parent_data_df["Date"] == date
                            ].values[0]

                if (
                    isin
                    not in parent_data_df.columns.tolist()
                    + consolidated_data_df.columns.tolist()
                ):
                    continue

            output_data.reset_index().to_csv(
                os.path.join(
                    config["output_directory"],
                    "raw_modified_files",
                    "Merge",
                    fundamental_data_type,
                    constants.FREQUENCIES[frequency],
                    f"{formula.replace('TR.', '')}_TR_{period}_{frequency}_Merge.csv",
                ),
                index=False,
            )

        except Exception as exe:
            print(f"Exception in {formula}", exe)


def download(config):
    fundamental_data_formula = pd.read_excel(
        config["fundamental_formula"], sheet_name=config["fundamental_sheet"]
    )
    print("Number of fundamentals are", len(fundamental_data_formula))

    isin_df = pd.read_excel(
        config["schema_fundamental"], sheet_name=config["schema_fundamental_sheet"]
    )
    print("Number of ISIN are", len(isin_df))

    fundamental_types = fundamental_data_formula["Type"].unique()
    isin_list = isin_df["ISIN"].unique().tolist()

    # Iterating over formulas
    for fundamental_type in fundamental_types:
        fundamental_type_df = fundamental_data_formula[
            fundamental_data_formula["Type"] == fundamental_type
        ]
        fundamental_data_formula = fundamental_type_df["Formula"].dropna().unique()
        fundamental_data_period = fundamental_type_df["period"].dropna().unique()

        for consolidation_type in config["consolidation_type"]:
            for period in fundamental_data_period:
                for frequency in config["frequencies"]:
                    download_fundamental_data(
                        config,
                        period,
                        consolidation_basis=consolidation_type,
                        frequency=frequency,
                        fundamental_data_type=fundamental_type,
                        isin_list=isin_list,
                        fundamental_data_formula_list=fundamental_data_formula,
                    )

    # Merge Consolidated & Parent Data
    for fundamental_type in fundamental_types:
        fundamental_data_type_df = fundamental_data_formula[
            fundamental_data_formula["Type"] == fundamental_type
        ]
        fundamental_data_formula = fundamental_data_type_df["Formula"].dropna().unique()
        fundamental_data_period = fundamental_data_type_df["period"].dropna().unique()
        
        for period in fundamental_data_period:
            for frequency in config["frequencies"]:
                merge_consolidated_parent_data(
                    config,
                    period,
                    frequency=frequency,
                    fundamental_data_type=fundamental_type,
                    isin_list=isin_list,
                    fundamental_data_formula=fundamental_data_formula
                )
