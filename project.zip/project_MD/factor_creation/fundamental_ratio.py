import os
import numpy as np
import pandas as pd
from common_utils import constants


def norm_fact(df, n):
    df = df.pct_change(12 * n)
    df.replace([np.inf, -np.inf], np.nan, inplace=True)
    return df


def financial_factors_ratios(config):
    for freq in config["frequencies"]:
        factor_path = os.path.join(config["factors_database_path"], constants.FREQUENCIES[freq])

        mapping_df = pd.read_excel(config["schema_path"], sheet_name="ISIN_mapping")
        financial_stocks = mapping_df["ISIN"][mapping_df["Sector"] == "Financials"].tolist()

        # read files from merge loc
        ebit_df = pd.read_csv(
            os.path.join(factor_path, f'EBIT_TR_{config["factor_ratio_period"]}_{freq}_Merge.csv'),
            index_col="Date",
        )
        ebitda_df = pd.read_csv(
            os.path.join(
                factor_path,
                f'EBITDA_TR_{config["factor_ratio_period"]}_{freq}_Merge.csv',
            ),
            index_col="Date",
        )
        total_revenue_df = pd.read_csv(
            os.path.join(
                factor_path,
                f'TotalRevenue_TR_{config["factor_ratio_period"]}_{freq}_Merge.csv',
            ),
            index_col="Date",
        )
        ev_df = pd.read_csv(
            os.path.join(factor_path, f'EV_TR_{config["factor_ratio_period"]}_{freq}_Merge.csv'),
            index_col="Date",
        )
        operating_expenses_df = pd.read_csv(
            os.path.join(
                factor_path,
                f'OperatingExpenses_TR_{config["factor_ratio_period"]}_{freq}_Merge.csv',
            ),
            index_col="Date",
        )
        total_equity_df = pd.read_csv(
            os.path.join(
                factor_path,
                f'TotalEquity_TR_{config["factor_ratio_period"]}_{freq}_Merge.csv',
            ),
            index_col="Date",
        )
        book_value_per_share_df = pd.read_csv(
            os.path.join(
                factor_path,
                f'BookValuePerShare_TR_{config["factor_ratio_period"]}_{freq}_Merge.csv',
            ),
            index_col="Date",
        )
        revenue_per_share_df = pd.read_csv(
            os.path.join(
                factor_path,
                f'RevenuePerShare_TR_{config["factor_ratio_period"]}_{freq}_Merge.csv',
            ),
            index_col="Date",
        )
        total_debt_outstanding_df = pd.read_csv(
            os.path.join(
                factor_path,
                f'TotalDebtOutstanding_TR_{config["factor_ratio_period"]}_{freq}_Merge.csv',
            ),
            index_col="Date",
        )
        basic_normalized_eps_df = pd.read_csv(
            os.path.join(
                factor_path,
                f'BasicNormalizedEps_TR_{config["factor_ratio_period"]}_{freq}_Merge.csv',
            ),
            index_col="Date",
        )
        tot_cash_from_operating_activities_df = pd.read_csv(
            os.path.join(
                factor_path,
                f'TotCashFromOperatingActivities_TR_{config["factor_ratio_period"]}_{freq}_Merge.csv',
            ),
            index_col="Date",
        )
        free_cash_flow_df = pd.read_csv(
            os.path.join(
                factor_path,
                f'FreeCashFlow_TR_{config["factor_ratio_period"]}_{freq}_Merge.csv',
            ),
            index_col="Date",
        )
        company_market_cap_df = pd.read_csv(
            os.path.join(
                factor_path,
                f'CompanyMarketCap_TR_{config["factor_ratio_period"]}_{freq}_Merge.csv',
            ),
            index_col="Date",
        )
        total_asset_reported_df = pd.read_csv(
            os.path.join(
                factor_path,
                f'TotalAssetsReported_TR_{config["factor_ratio_period"]}_{freq}_Merge.csv',
            ),
            index_col="Date",
        )
        no_strong_buy_df = pd.read_csv(
            os.path.join(
                factor_path,
                f'NumOfStrongBuy_TR_{config["factor_ratio_period"]}_{freq}_Merge.csv',
            ),
            index_col="Date",
        )
        no_buy_df = pd.read_csv(
            os.path.join(
                factor_path,
                f'NumOfBuy_TR_{config["factor_ratio_period"]}_{freq}_Merge.csv',
            ),
            index_col="Date",
        )
        no_strong_sell_df = pd.read_csv(
            os.path.join(
                factor_path,
                f'NumOfStrongSell_TR_{config["factor_ratio_period"]}_{freq}_Merge.csv',
            ),
            index_col="Date",
        )
        no_sell_df = pd.read_csv(
            os.path.join(
                factor_path,
                f'NumOfSell_TR_{config["factor_ratio_period"]}_{freq}_Merge.csv',
            ),
            index_col="Date",
        )
        total_inventory_df = pd.read_csv(
            os.path.join(
                factor_path,
                f'TotalInventory_TR_{config["factor_ratio_period"]}_{freq}_Merge.csv',
            ),
            index_col="Date",
        )
        total_liabilities_df = pd.read_csv(
            os.path.join(
                factor_path,
                f'TotalLiabilities_TR_{config["factor_ratio_period"]}_{freq}_Merge.csv',
            ),
            index_col="Date",
        )
        total_receivables_net_df = pd.read_csv(
            os.path.join(
                factor_path,
                f'TotalReceivablesNet_TR_{config["factor_ratio_period"]}_{freq}_Merge.csv',
            ),
            index_col="Date",
        )
        dps_common_stock_df = pd.read_csv(
            os.path.join(
                factor_path,
                f'DpsCommonStock_TR_{config["factor_ratio_period"]}_{freq}_Merge.csv',
            ),
            index_col="Date",
        )
        revenue_df = pd.read_csv(
            os.path.join(
                factor_path,
                f'Revenue_TR_{config["factor_ratio_period"]}_{freq}_Merge.csv',
            ),
            index_col="Date",
        )
        return_on_capital_perc_df = pd.read_csv(
            os.path.join(
                factor_path,
                f'ReturnOnCapitalPercent_TR_{config["factor_ratio_period"]}_{freq}_Merge.csv',
            ),
            index_col="Date",
        )

        closing_price_df = pd.read_csv(
            os.path.join(config["ohlc_folder_path"], f"Price_Close_{constants.FREQUENCIES[freq]}.csv"),
            index_col="Date",
        )

        total_debt_outstanding_to_ebitda_df = total_debt_outstanding_df / ebitda_df
        tot_cash_from_operating_activities_to_company_market_cap_df = tot_cash_from_operating_activities_df / company_market_cap_df
        free_cash_flow_to_company_market_cap_df = free_cash_flow_df / company_market_cap_df
        gross_profit_to_revenue_df = (total_revenue_df - operating_expenses_df) / total_revenue_df
        equity_to_debt_df = total_equity_df / total_debt_outstanding_df
        debt_to_equity_df = total_debt_outstanding_df / total_equity_df
        roe_df = (total_revenue_df - operating_expenses_df) / total_equity_df
        pe_df = closing_price_df / basic_normalized_eps_df
        ep_df = basic_normalized_eps_df / closing_price_df
        pb_df = closing_price_df / book_value_per_share_df
        bp_df = book_value_per_share_df / closing_price_df
        sp_df = revenue_per_share_df / closing_price_df
        ps_df = closing_price_df / revenue_per_share_df
        dividend_yield_df = dps_common_stock_df / closing_price_df
        ev_to_ebitda_df = ev_df / ebitda_df
        gross_profit_to_total_asset_df = (total_revenue_df - operating_expenses_df) / total_asset_reported_df
        gross_profit_to_market_cap_df = (total_revenue_df - operating_expenses_df) / company_market_cap_df
        free_cash_flow_to_sales_df = free_cash_flow_df / revenue_df
        ebit_to_sales_df = ebit_df / total_revenue_df
        ebit_to_market_cap_df = ebit_df / company_market_cap_df
        ebitda_to_sales_df = ebitda_df / total_revenue_df
        buy_to_sell_df = (no_buy_df + no_strong_buy_df) / (no_sell_df + no_strong_sell_df)
        buy_percentage_df = (no_buy_df + no_strong_buy_df) / (no_buy_df + no_strong_buy_df + no_sell_df + no_strong_sell_df)
        sustainable_growth_rate_df = roe_df * (1 - dps_common_stock_df / basic_normalized_eps_df)
        total_inventory_to_total_asset_1_yr_df = total_inventory_df.diff() / total_asset_reported_df
        total_receivables_to_total_asset_1_yr_df = total_receivables_net_df.diff() / total_asset_reported_df

        total_revenue_change_2_df = norm_fact(total_revenue_df, 2)
        total_revenue_change_1_df = norm_fact(total_revenue_df, 1)
        ebit_change_1_df = norm_fact(ebit_df, 1)
        total_liabilities_change_1_df = norm_fact(total_liabilities_df, 1)
        total_liabilities_change_2_df = norm_fact(total_liabilities_df, 2)
        gross_profit_to_total_asset_change_1_df = norm_fact(gross_profit_to_total_asset_df, 1)
        gross_profit_to_total_asset_change_2_df = norm_fact(gross_profit_to_total_asset_df, 2)
        roe_change_1_df = norm_fact(roe_df, 1)
        roe_change_2_df = norm_fact(roe_df, 2)
        ep_change_1_df = norm_fact(ep_df, 1)
        ep_change_2_df = norm_fact(ep_df, 2)
        ebit_to_mc_df = ebit_df / company_market_cap_df
        ebit_to_mc_df_change_1_df = norm_fact(ebit_to_mc_df, 1)
        ebit_to_mc_df_change_2_df = norm_fact(ebit_to_mc_df, 2)
        ebit_to_revenue_change_1_df = ebit_change_1_df / total_revenue_change_1_df
        return_on_capital_perc_df[financial_stocks] = roe_df[financial_stocks]

        # Export the Data
        total_debt_outstanding_to_ebitda_df.to_csv(
            os.path.join(
                config["factor_save_path"],
                f'TOTALDEBTTOEBITDA_{config["factor_ratio_period"]}_{freq}.csv',
            )
        )
        tot_cash_from_operating_activities_to_company_market_cap_df.to_csv(
            os.path.join(
                config["factor_save_path"],
                f'OPERATINGCASHFLOWTOMARKETCAP_{config["factor_ratio_period"]}_{freq}.csv',
            )
        )
        free_cash_flow_to_company_market_cap_df.to_csv(
            os.path.join(
                config["factor_save_path"],
                f'FREECASHFLOWTOMARKETCAP_{config["factor_ratio_period"]}_{freq}.csv',
            )
        )
        gross_profit_to_revenue_df.to_csv(
            os.path.join(
                config["factor_save_path"],
                f'GROSSPROFITTOREVENUE{config["factor_ratio_period"]}_{freq}.csv',
            )
        )
        equity_to_debt_df.to_csv(
            os.path.join(
                config["factor_save_path"],
                f'EQUITYTODEBT_{config["factor_ratio_period"]}_{freq}.csv',
            )
        )
        debt_to_equity_df.to_csv(
            os.path.join(
                config["factor_save_path"],
                f'DEBTTOEQUITY_{config["factor_ratio_period"]}_{freq}.csv',
            )
        )
        roe_df.to_csv(
            os.path.join(
                config["factor_save_path"],
                f'ROE_{config["factor_ratio_period"]}_{freq}.csv',
            )
        )
        pe_df.to_csv(
            os.path.join(
                config["factor_save_path"],
                f'PE_{config["factor_ratio_period"]}_{freq}.csv',
            )
        )
        ep_df.to_csv(
            os.path.join(
                config["factor_save_path"],
                f'EP_{config["factor_ratio_period"]}_{freq}.csv',
            )
        )
        pb_df.to_csv(
            os.path.join(
                config["factor_save_path"],
                f'PB_{config["factor_ratio_period"]}_{freq}.csv',
            )
        )
        bp_df.to_csv(
            os.path.join(
                config["factor_save_path"],
                f'BP_{config["factor_ratio_period"]}_{freq}.csv',
            )
        )
        sp_df.to_csv(
            os.path.join(
                config["factor_save_path"],
                f'SP_{config["factor_ratio_period"]}_{freq}.csv',
            )
        )
        ps_df.to_csv(
            os.path.join(
                config["factor_save_path"],
                f'PS_{config["factor_ratio_period"]}_{freq}.csv',
            )
        )
        dividend_yield_df.to_csv(
            os.path.join(
                config["factor_save_path"],
                f'DIVIDENDYIELD_{config["factor_ratio_period"]}_{freq}.csv',
            )
        )
        ev_to_ebitda_df.to_csv(
            os.path.join(
                config["factor_save_path"],
                f'EVTOEBITDA_{config["factor_ratio_period"]}_{freq}.csv',
            )
        )
        gross_profit_to_total_asset_df.to_csv(
            os.path.join(
                config["factor_save_path"],
                f'GROSSPROFITTOTOTALASSET_{config["factor_ratio_period"]}_{freq}.csv',
            )
        )
        gross_profit_to_market_cap_df.to_csv(
            os.path.join(
                config["factor_save_path"],
                f'GROSSPROFITTOMARKETCAP_{config["factor_ratio_period"]}_{freq}.csv',
            )
        )
        free_cash_flow_to_sales_df.to_csv(
            os.path.join(
                config["factor_save_path"],
                f'FREECASHFLOWTOSALES_{config["factor_ratio_period"]}_{freq}.csv',
            )
        )
        ebit_to_sales_df.to_csv(
            os.path.join(
                config["factor_save_path"],
                f'EBITTOSALES_{config["factor_ratio_period"]}_{freq}.csv',
            )
        )
        ebit_to_market_cap_df.to_csv(
            os.path.join(
                config["factor_save_path"],
                f'EBITTOMARKETCAP_{config["factor_ratio_period"]}_{freq}.csv',
            )
        )
        ebitda_to_sales_df.to_csv(
            os.path.join(
                config["factor_save_path"],
                f'EBITDATOSALES_{config["factor_ratio_period"]}_{freq}.csv',
            )
        )
        buy_to_sell_df.to_csv(
            os.path.join(
                config["factor_save_path"],
                f'BUY_TO_SELL_{config["factor_ratio_period"]}_{freq}.csv',
            )
        )
        buy_percentage_df.to_csv(
            os.path.join(
                config["factor_save_path"],
                f'BUY_PERCENTAGE_{config["factor_ratio_period"]}_{freq}.csv',
            )
        )
        sustainable_growth_rate_df.to_csv(
            os.path.join(
                config["factor_save_path"],
                f'SUSTAINABLEGROWTHRATE_{config["factor_ratio_period"]}_{freq}.csv',
            )
        )
        total_inventory_to_total_asset_1_yr_df.to_csv(
            os.path.join(
                config["factor_save_path"],
                f'1YRCHTOTALINVENTORYTOTOTALASSET_{config["factor_ratio_period"]}_{freq}.csv',
            )
        )
        total_receivables_to_total_asset_1_yr_df.to_csv(
            os.path.join(
                config["factor_save_path"],
                f'1YRCHTOTALRECEIVABLESTOTOTALASSET_{config["factor_ratio_period"]}_{freq}.csv',
            )
        )
        total_revenue_change_1_df.to_csv(
            os.path.join(
                config["factor_save_path"],
                f'TOTALREVENUE_CHANGE1_{config["factor_ratio_period"]}_{freq}.csv',
            )
        )
        total_revenue_change_2_df.to_csv(
            os.path.join(
                config["factor_save_path"],
                f'TOTALREVENUE_CHANGE2_{config["factor_ratio_period"]}_{freq}.csv',
            )
        )
        total_liabilities_change_1_df.to_csv(
            os.path.join(
                config["factor_save_path"],
                f'TOTALLIABILITIES_CHANGE1_{config["factor_ratio_period"]}_{freq}.csv',
            )
        )
        total_liabilities_change_2_df.to_csv(
            os.path.join(
                config["factor_save_path"],
                f'TOTALLIABILITIES_CHANGE2_{config["factor_ratio_period"]}_{freq}.csv',
            )
        )
        company_market_cap_df.to_csv(
            os.path.join(
                config["factor_save_path"],
                f'CompanyMarketCap_TR_{config["factor_ratio_period"]}_{freq}.csv',
            )
        )
        gross_profit_to_total_asset_change_1_df.to_csv(
            os.path.join(
                config["factor_save_path"],
                f'GPtoA_CHANGE1_{config["factor_ratio_period"]}_{freq}.csv',
            )
        )
        gross_profit_to_total_asset_change_2_df.to_csv(
            os.path.join(
                config["factor_save_path"],
                f'GPtoA_CHANGE2_{config["factor_ratio_period"]}_{freq}.csv',
            )
        )
        roe_change_1_df.to_csv(
            os.path.join(
                config["factor_save_path"],
                f'ROE_CHANGE1_{config["factor_ratio_period"]}_{freq}.csv',
            )
        )
        roe_change_2_df.to_csv(
            os.path.join(
                config["factor_save_path"],
                f'ROE_CHANGE2_{config["factor_ratio_period"]}_{freq}.csv',
            )
        )
        ep_change_1_df.to_csv(
            os.path.join(
                config["factor_save_path"],
                f'EP_CHANGE1_{config["factor_ratio_period"]}_{freq}.csv',
            )
        )
        ep_change_2_df.to_csv(
            os.path.join(
                config["factor_save_path"],
                f'EP_CHANGE2_{config["factor_ratio_period"]}_{freq}.csv',
            )
        )
        ebit_to_mc_df_change_1_df.to_csv(
            os.path.join(
                config["factor_save_path"],
                f'EBITtoMC_CHANGE1_{config["factor_ratio_period"]}_{freq}.csv',
            )
        )
        ebit_to_mc_df_change_2_df.to_csv(
            os.path.join(
                config["factor_save_path"],
                f'EBITtoMC_CHANGE2_{config["factor_ratio_period"]}_{freq}.csv',
            )
        )
        ebit_to_revenue_change_1_df.to_csv(
            os.path.join(
                config["factor_save_path"],
                f'EBITtoREVENUE_CHANGE1_{config["factor_ratio_period"]}_{freq}.csv',
            )
        )
        return_on_capital_perc_df.to_csv(
            os.path.join(
                config["factor_save_path"],
                f'ROE_ROCE_{config["factor_ratio_period"]}_{freq}.csv',
            )
        )
