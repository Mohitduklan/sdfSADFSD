import os
import numpy as np
from factor_creation.iMomentum import iMom_regression
from factor_creation.iVol import iVol_regression
from factor_creation.alpha_beta import alpha_beta_regression


# TODO: structure the code
def regression_based_factors(config, isin_weekly, isin_monthly, index_weekly, index_monthly):
    print("iVol Monthly...!!!")
    weekly_return = np.log(isin_weekly) - np.log(isin_weekly.shift(1))
    index_weekly_return = (np.log(index_weekly["Close"]) - np.log(index_weekly["Close"].shift(1))).dropna()
    std = 0
    freq = "M"
    iVol_regression_df = iVol_regression(
        index_return=index_weekly_return,
        stocks_return=weekly_return,
        std=std,
        freq=freq,
    )
    iVol_regression_df.to_csv(os.path.join(config[r"factor_save_path"], f"iVol_52weeks_Std_{std}_{freq}.csv"))

    print("iMom Monthly")
    monthly_return = np.log(isin_monthly) - np.log(isin_monthly.shift(1))
    index_monthly_return = (np.log(index_monthly["Close"]) - np.log(index_monthly["Close"].shift(1))).dropna()
    residual_cumprod_6_df, residual_cumprod_12_df = iMom_regression(
        index_return=index_monthly_return,
        stocks_return=monthly_return,
        std=std,
        freq=freq,
    )
    residual_cumprod_6_df.to_csv(os.path.join(config[r"factor_save_path"], f"iMom_6m_1m_lagged_Std_{std}_{freq}.csv"))
    residual_cumprod_12_df.to_csv(os.path.join(config[r"factor_save_path"], f"iMom_12m_1m_lagged_Std_{std}_{freq}.csv"))

    print("beta Monthly")
    for lby in [2, 3]:
        regression_alpha_df, regression_beta_df = alpha_beta_regression(
            index_return=index_monthly_return,
            stocks_return=monthly_return,
            freq=freq,
            look_back_year=lby,
        )
        regression_alpha_df.to_csv(os.path.join(config[r"factor_save_path"], f"Alpha_{lby}_years_{freq}.csv"))
        regression_beta_df.to_csv(os.path.join(config[r"factor_save_path"], f"Beta_{lby}_years_{freq}.csv"))
