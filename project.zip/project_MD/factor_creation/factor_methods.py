import numpy as np
import pandas as pd


def to_excess_returns(returns, rf, nperiods=None):
    """
    Given a series of returns, it will return the excess returns over rf.

    Args:
        * returns (Series, DataFrame): Returns
        * rf (float, Series): `Risk-Free rate(s) <https://www.investopedia.com/terms/r/risk-freerate.asp>`_ expressed in annualized term or return series
        * nperiods (int): Optional. If provided, will convert rf to different
            frequency using deannualize only if rf is a float
    Returns:
        * excess_returns (Series, DataFrame): Returns - rf

    """
    rf_d = rf
    if isinstance(rf, float) and nperiods is not None:
        rf_d = deannualize(rf, nperiods)

    print("deannualize risk free rate is : ", rf_d)
    return returns - rf_d


def deannualize(returns, nperiods):
    """
    Convert return expressed in annual terms on a different basis.

    Args:
        * returns (float, Series, DataFrame): Return(s)
        * nperiods (int): Target basis, typically 252 for daily, 12 for
            monthly, etc.

    """
    return np.power(1 + returns, 1.0 / nperiods) - 1.0

def calc_down_side_deviation(returns, nperiods, freq):
    """Calculates downside deviation : ignores +ve values"""
    negative_returns = np.minimum(returns, 0)

    res = negative_returns.rolling(nperiods).std() * np.sqrt(nperiods)

    if freq == "W":
        freq = "W-Fri"

    res = res.resample(freq).last()
    res.index.names = ["Date"]

    return res


def calc_up_side_deviation(returns, nperiods, freq):
    """Calculates upside deviation : ignores -ve values"""
    positive_returns = np.maximum(returns, 0)

    res = positive_returns.rolling(nperiods).std() * np.sqrt(nperiods)

    if freq == "W":
        freq = "W-Fri"

    res = res.resample(freq).last()
    res.index.names = ["Date"]

    return res


def calc_kelly_non_annualized(returns, nperiods, freq):
    res = returns.rolling(nperiods).mean() / returns.rolling(nperiods).var()

    if freq == "W":
        freq = "W-Fri"

    res = res.resample(freq).last()
    res.index.names = ["Date"]

    return res


def calc_sharpe(returns, nperiods, freq, rf=0.0, annualize=True):
    """
    Calculates the `Sharpe ratio <https://www.investopedia.com/terms/s/sharperatio.asp>`_
    (see `Sharpe vs. Sortino <https://www.investopedia.com/ask/answers/010815/what-difference-between-sharpe-ratio-and-sortino-ratio.asp>`_).

    If rf is non-zero and a float, you must specify nperiods. In this case, rf is assumed
    to be expressed in yearly (annualized) terms.

    Args:
        * returns (Series, DataFrame): Input return series
        * rf (float, Series): `Risk-free rate <https://www.investopedia.com/terms/r/risk-freerate.asp>`_ expressed as a yearly (annualized) return or return series
        * nperiods (int): Frequency of returns (252 for daily, 12 for monthly,
            etc.)
    """
    if isinstance(rf, float) and rf != 0 and nperiods is None:
        raise Exception("Must provide nperiods if rf != 0")

    er = to_excess_returns(returns, rf, nperiods=nperiods)
    std = er.rolling(nperiods).std(ddof=1)
    res = np.divide(er.rolling(nperiods).mean(), std)

    if annualize:
        if nperiods is None:
            nperiods = 1
        res = res * np.sqrt(nperiods)

    if freq == "W":
        freq = "W-Fri"

    res = res.resample(freq).last()
    res.index.names = ["Date"]

    return res


def calc_sortino_ratio(returns, nperiods, freq, rf=0.0, annualize=True):
    """
    Calculates the `Sortino ratio <https://www.investopedia.com/terms/s/sortinoratio.asp>`_ given a series of returns
    (see `Sharpe vs. Sortino <https://www.investopedia.com/ask/answers/010815/what-difference-between-sharpe-ratio-and-sortino-ratio.asp>`_).

    Args:
        * returns (Series or DataFrame): Returns
        * rf (float, Series): `Risk-free rate <https://www.investopedia.com/terms/r/risk-freerate.asp>`_ expressed in yearly (annualized) terms or return series.
        * nperiods (int): Number of periods used for annualization. Must be
            provided if rf is non-zero and rf is not a price series

    """
    # if type(rf) is float and rf != 0 and nperiods is None:
    if isinstance(rf, float) and rf != 0 and nperiods is None:
        raise Exception("nperiods must be set if rf != 0 and rf is not a price series")

    er = to_excess_returns(returns, rf, nperiods=nperiods)
    negative_returns = np.minimum(er, 0.0)
    std = negative_returns.rolling(nperiods).std(ddof=1)
    res = np.divide(er.rolling(nperiods).mean(), std)

    if annualize:
        if nperiods is None:
            nperiods = 1
        res = res * np.sqrt(nperiods)

    if freq == "W":
        freq = "W-Fri"

    res = res.resample(freq).last()
    res.index.names = ["Date"]

    return res


def calc_vol_factor(returns, vol_period, nperiods, freq):
    res = returns.rolling(int(vol_period)).std() * np.sqrt(nperiods)

    if freq == "W":
        freq = "W-Fri"

    res = res.resample(freq).last()
    res.index.names = ["Date"]

    return res


def calc_price_momentum(price, mom_period, lag_by=0):
    price = price.replace("nan", np.nan).fillna(method="ffill")
    res = np.log(price) - np.log(price.shift(mom_period))
    res = res.replace(0, np.nan)
    res = res.shift(lag_by)
    res.index.names = ["Date"]
    return res


def calc_cross_sectional_momentum(price, index_price, mom_period):
    price = price.replace("nan", np.nan).fillna(method="ffill")
    index_price = index_price.replace("nan", np.nan).fillna(method="ffill")

    price_return = np.log(price) - np.log(price.shift(mom_period))
    index_return = np.log(index_price) - np.log(index_price.shift(mom_period))

    res = pd.DataFrame(
        data=price_return.values - index_return.values,
        index=price_return.index,
        columns=price_return.columns,
    )
    res = res.replace(0, np.nan)

    outperform_index = res[res > 0]

    res.index.names = ["Date"]
    outperform_index.index.names = ["Date"]

    return res, outperform_index


def calc_price_momentum_index_ratio(price, index_price, mom_period, freq):
    # TODO: Make this generic
    price = price.replace("nan", np.nan).fillna(method="ffill")
    index_price = index_price.replace("nan", np.nan).fillna(method="ffill")

    price_return = np.log(price) - np.log(price.shift(mom_period))
    index_return = np.log(index_price) - np.log(index_price.shift(mom_period))

    cumprod_df_price_and_index = pd.concat([(price_return + 1).cumprod(), (index_return + 1).cumprod()], axis=1)
    price_index_ratio = cumprod_df_price_and_index[price_return.columns].div(cumprod_df_price_and_index[index_return.columns].values, axis=0)
    price_index_ratio.dropna(how="all", inplace=True)

    price_index_ratio_return = np.log(price_index_ratio) - np.log(price_index_ratio.shift(1))

    negative_returns = np.minimum(price_index_ratio_return, 0.0)

    daily_sortino = (price_index_ratio_return.rolling(252).mean() / negative_returns.rolling(252).std()) * np.sqrt(252)

    if freq == "D":
        momentum_6m = calc_price_momentum(price_index_ratio, 126)
        momentum_12m = calc_price_momentum(price_index_ratio, 252)
        momentum_1m = calc_price_momentum(price_index_ratio, 21)
        return momentum_1m, momentum_6m, momentum_12m, daily_sortino
    elif freq == "W":
        freq = "W-Fri"
        output = price_index_ratio.resample(freq).last()
        momentum_6m = calc_price_momentum(output, 26)
        momentum_12m = calc_price_momentum(output, 52)
        momentum_1m = calc_price_momentum(output, 4)
        weekly_sortino = daily_sortino.resample(freq).last()
        return momentum_1m, momentum_6m, momentum_12m, weekly_sortino
    elif freq == "M":
        output = price_index_ratio.resample(freq).last()
        momentum_6m = calc_price_momentum(output, 6)
        momentum_12m = calc_price_momentum(output, 12)
        momentum_1m = calc_price_momentum(output, 1)
        monthly_sortino = daily_sortino.resample(freq).last()
        return momentum_1m, momentum_6m, momentum_12m, monthly_sortino
