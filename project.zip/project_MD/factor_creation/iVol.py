import pandas as pd
import statsmodels.api as sm
import tqdm


def iVol_regression(index_return, stocks_return, std, freq, look_back_year=3):
    isin_lst = stocks_return.columns.tolist()
    regression_df = pd.DataFrame(index=isin_lst)

    obs_per_year = 52
    # if freq == 'W':
    #     obs_per_year = 52
    # if freq == 'M':
    #     obs_per_year = 12

    for i in tqdm.tqdm(range(0, index_return.shape[0] - look_back_year * obs_per_year)):
        stop = i + look_back_year * obs_per_year
        residual_std_lst = list()
        for isin in isin_lst:
            data = pd.concat([index_return, stocks_return[isin]], axis=1)
            data = data[index_return.index[i] : index_return.index[stop]]
            X = data["Close"]
            y = data[isin]

            if std == 1:
                X = X.sub(X.mean()).div(X.std())
                y = y.sub(y.mean()).div(y.std())

            X = sm.add_constant(X)
            reg_residual = sm.OLS(y, X).fit()
            residual = reg_residual.resid
            residual_std = residual[-obs_per_year - 1 : -1].std()
            residual_std_lst.append([isin, residual_std])

        residual_std_df = pd.DataFrame(residual_std_lst, columns=["ISIN", index_return.index[stop]])
        residual_std_df.set_index("ISIN", inplace=True)
        regression_df = pd.concat([regression_df, residual_std_df], axis=1)

    regression_df = regression_df.T
    regression_df.index = pd.to_datetime(regression_df.index)
    regression_df.index.name = "Date"
    regression_df = regression_df.replace(0, "")

    if freq == "M":
        output = regression_df.resample("M").last()
    elif freq == "W":
        output = regression_df

    return output
