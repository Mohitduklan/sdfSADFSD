import pandas as pd
import statsmodels.api as sm
import tqdm


def iMom_regression(index_return, stocks_return, std, freq, look_back_year=3):
    isin_lst = stocks_return.columns.tolist()
    regression_6_df = pd.DataFrame(index=isin_lst)
    regression_12_df = pd.DataFrame(index=isin_lst)

    if freq == "W":
        obs_per_year = 52
    if freq == "M":
        obs_per_year = 12

    for i in tqdm.tqdm(range(0, index_return.shape[0] - look_back_year * obs_per_year)):
        stop = i + look_back_year * obs_per_year
        residual_cumprod_6_lst = list()
        residual_cumprod_12_lst = list()

        for isin in isin_lst:
            data = pd.concat([index_return, stocks_return[isin]], axis=1)
            data = data[index_return.index[i] : index_return.index[stop]]
            X = data["Close"]
            y = data[isin]

            if std == 1:
                X = X.sub(X.mean()).div(X.std())
                y = y.sub(y.mean()).div(y.std())

            X = sm.add_constant(X)
            reg_residual = sm.OLS(y, X).fit()
            residual = reg_residual.resid
            if freq == "M":
                residual_cumprod_6 = (residual[-7:-1] + 1).cumprod()
                residual_cumprod_12 = (residual[-13:-1] + 1).cumprod()
                residual_cumprod_6_denom = residual[-7:-1].std()
                residual_cumprod_12_denom = residual[-13:-1].std()
            if freq == "W":
                residual_cumprod_6 = (residual[-7 * 4 : -1 * 4] + 1).cumprod()
                residual_cumprod_12 = (residual[-13 * 4 : -1 * 4] + 1).cumprod()
                residual_cumprod_6_denom = residual[-7 * 4 : -1 * 4].std()
                residual_cumprod_12_denom = residual[-13 * 4 : -1 * 4].std()

            if std == 1:
                residual_cumprod_6_lst.append([isin, residual_cumprod_6[-1] - 1])
                residual_cumprod_12_lst.append([isin, residual_cumprod_12[-1] - 1])
            if std == 0:
                residual_cumprod_6_lst.append([isin, (residual_cumprod_6[-1] - 1) / residual_cumprod_6_denom])
                residual_cumprod_12_lst.append([isin, (residual_cumprod_12[-1] - 1) / residual_cumprod_12_denom])

        residual_cumprod_6_df = pd.DataFrame(residual_cumprod_6_lst, columns=["ISIN", index_return.index[stop]])
        residual_cumprod_6_df.set_index("ISIN", inplace=True)
        regression_6_df = pd.concat([regression_6_df, residual_cumprod_6_df], axis=1)

        residual_cumprod_12_df = pd.DataFrame(residual_cumprod_12_lst, columns=["ISIN", index_return.index[stop]])
        residual_cumprod_12_df.set_index("ISIN", inplace=True)
        regression_12_df = pd.concat([regression_12_df, residual_cumprod_12_df], axis=1)

    regression_6_df = regression_6_df.T
    regression_6_df.index = pd.to_datetime(regression_6_df.index)
    regression_6_df.index.name = "Date"
    # residual_cumprod_6_df = residual_cumprod_6_df.replace(0, '')

    regression_12_df = regression_12_df.T
    regression_12_df.index = pd.to_datetime(regression_12_df.index)
    regression_12_df.index.name = "Date"
    # residual_cumprod_12_df = residual_cumprod_12_df.replace(0, '')

    return regression_6_df, regression_12_df
