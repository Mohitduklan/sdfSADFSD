import pandas as pd
import statsmodels.api as sm
import tqdm


def alpha_beta_regression(index_return, stocks_return, freq, look_back_year=3):
    isin_lst = stocks_return.columns.tolist()
    regression_alpha_df = pd.DataFrame(index=isin_lst)
    regression_beta_df = pd.DataFrame(index=isin_lst)

    if freq == "W":
        obs_per_year = 52
    if freq == "M":
        obs_per_year = 12

    for i in tqdm.tqdm(range(0, index_return.shape[0] - look_back_year * obs_per_year)):
        stop = i + look_back_year * obs_per_year
        alpha_lst = list()
        beta_lst = list()

        for isin in isin_lst:
            data = pd.concat([index_return, stocks_return[isin]], axis=1)
            data = data[index_return.index[i] : index_return.index[stop]]
            X = data["Close"]
            y = data[isin]
            X = sm.add_constant(X)
            reg_residual = sm.OLS(y, X).fit()

            alpha = reg_residual.params[0]
            beta = reg_residual.params[1]
            alpha_lst.append([isin, alpha])
            beta_lst.append([isin, beta])

        alpha_df = pd.DataFrame(alpha_lst, columns=["ISIN", index_return.index[stop]])
        alpha_df.set_index("ISIN", inplace=True)
        regression_alpha_df = pd.concat([regression_alpha_df, alpha_df], axis=1)

        beta_df = pd.DataFrame(beta_lst, columns=["ISIN", index_return.index[stop]])
        beta_df.set_index("ISIN", inplace=True)
        regression_beta_df = pd.concat([regression_beta_df, beta_df], axis=1)

    regression_alpha_df = regression_alpha_df.T
    regression_alpha_df.index = pd.to_datetime(regression_alpha_df.index)
    regression_alpha_df.index.name = "Date"
    # regression_alpha_df = regression_alpha_df.replace(0, '')

    regression_beta_df = regression_beta_df.T
    regression_beta_df.index = pd.to_datetime(regression_beta_df.index)
    regression_beta_df.index.name = "Date"
    # regression_beta_df = regression_beta_df.replace(0, '')

    return regression_alpha_df, regression_beta_df
