import os
import numpy as np
from factor_creation.factor_methods import (
    calc_price_momentum,
    calc_cross_sectional_momentum,
    calc_price_momentum_index_ratio,
)


def momentum_factors(config, isin_monthly):
    for mom_period in config["momentum_period"]:
        price_momentum = calc_price_momentum(isin_monthly, mom_period=mom_period)
        price_momentum.to_csv(os.path.join(config["factor_save_path"], f"Price_Momentum_{mom_period}m_M.csv"))


def cross_sectional_momentum_with_BSE200(config, isin_monthly, index_monthly):
    for mom_period in config["momentum_period"]:
        cross_sectional_momentum, outperform_index = calc_cross_sectional_momentum(isin_monthly, index_monthly, mom_period=mom_period)
        cross_sectional_momentum.to_csv(
            os.path.join(
                config["factor_save_path"],
                f"CrossSectional_Momentum_RelBSE200_{mom_period}m_M.csv",
            )
        )
        outperform_index.to_csv(
            os.path.join(
                config["factor_save_path"],
                f"CrossSectional_Momentum_OutperfBSE200_{mom_period}m_M.csv",
            )
        )


def lagged_price_momentum(config, isin_monthly):
    price_momentum_lag_12_1 = calc_price_momentum(isin_monthly, mom_period=12, lag_by=1)
    price_momentum_lag_6_6 = calc_price_momentum(isin_monthly, mom_period=6, lag_by=6)
    price_momentum_lag_12_1.to_csv(os.path.join(config["factor_save_path"], f"Price_Momentum_12m_1m_lag_M.csv"))
    price_momentum_lag_6_6.to_csv(os.path.join(config["factor_save_path"], f"Price_Momentum_6m_6m_lag_M.csv"))


def weighted_lagged_price_momentum(config, isin_monthly):
    price_momentum_lag_12_1 = calc_price_momentum(isin_monthly, mom_period=12, lag_by=1)
    price_momentum_lag_12_1_price_momentum_1 = 0.5 * price_momentum_lag_12_1 + 0.5 * calc_price_momentum(isin_monthly, mom_period=1)
    price_momentum_lag_12_1_price_momentum_2 = 0.5 * price_momentum_lag_12_1 + 0.5 * calc_price_momentum(isin_monthly, mom_period=2)
    price_momentum_lag_12_1_price_momentum_3 = 0.6 * price_momentum_lag_12_1 + 0.4 * calc_price_momentum(isin_monthly, mom_period=3)
    price_momentum_lag_12_1_price_momentum_1.to_csv(
        os.path.join(
            config["factor_save_path"],
            f"Price_Momentum_12m_1m_lag_Price_Momentum_1m_M.csv",
        )
    )
    price_momentum_lag_12_1_price_momentum_2.to_csv(
        os.path.join(
            config["factor_save_path"],
            f"Price_Momentum_12m_1m_lag_Price_Momentum_2m_M.csv",
        )
    )
    price_momentum_lag_12_1_price_momentum_3.to_csv(
        os.path.join(
            config["factor_save_path"],
            f"Price_Momentum_12m_1m_lag_Price_Momentum_3m_M.csv",
        )
    )


def price_momentum_ratios_monthly(config, isin_monthly, index_monthly):
    (
        pir_momentum_1m,
        pir_momentum_6m,
        pir_momentum_12m,
        pir_sortino,
    ) = calc_price_momentum_index_ratio(isin_monthly, index_monthly, mom_period=1, freq="M")
    pir_momentum_1m.to_csv(os.path.join(config["factor_save_path"], "Price_Index_Ratio_Momentum_1m_M.csv"))
    pir_momentum_6m.to_csv(os.path.join(config["factor_save_path"], "Price_Index_Ratio_Momentum_6m_M.csv"))
    pir_momentum_12m.to_csv(os.path.join(config["factor_save_path"], "Price_Index_Ratio_Momentum_12m_M.csv"))
    pir_sortino.to_csv(os.path.join(config["factor_save_path"], "Price_Index_Ratio_Sortino_Ratio_M.csv"))
